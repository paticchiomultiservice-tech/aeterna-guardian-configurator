# AETERNA Digital Legacy · Verbale e registri del pilota URP

Modello per l’esercitazione dimostrativa. Usare dati inventati. Conservare il verbale aggregato nei sistemi indicati dall’ente.

## Prima della prova

- Definire con l’ente un solo servizio, l’ufficio che conduce, il referente e il sostituto. Concordare chi autorizza la rettifica e come l’operatore riceve conferma.
- Scegliere un canale alternativo indipendente dal guasto simulato. Predisporre un percorso in presenza e una scheda stampabile per chi è senza telefono o fotocamera.
- Concordare il numero di tentativi comparabili, le soglie in conteggi e i tempi massimi. Le soglie suggerite nella pagina sono esempi da adattare prima della prova.
- Preparare il cartoncino per l’esercizio B e due copie chiaramente fittizie per l’esercizio A. Tenere la copia corrente alla bacheca di prova. Usare un ambiente separato con canali simulati.
- Provare la scheda con tastiera, lettore di schermo e testo ingrandito. Verificare che la stampa resti leggibile e che ogni istruzione essenziale si trovi anche senza QR.

## Verbale aggregato

| Meccanismo osservato | Soglia concordata | Prima sessione | Variante, sette giorni dopo | Ostacolo e correzione |
| --- | --- | --- | --- | --- |
| A · Verifica della fonte e rettifica autorizzata sul canale indipendente | ___ su ___, entro ___ min | ___ su ___, mediana ___ min | ___ su ___, mediana ___ min | ___ |
| A · La persona trova la rettifica senza fotocamera e riconosce la versione | ___ su ___, entro ___ min | ___ su ___, mediana ___ min | ___ su ___, mediana ___ min | ___ |
| B · Passaggio al ruolo previsto e conferma di ricezione | ___ su ___, entro ___ min | ___ su ___, mediana ___ min | ___ su ___, mediana ___ min | ___ |
| B · Individuazione del ruolo che autorizza la comunicazione | ___ su ___ | ___ su ___ | ___ su ___ | ___ |

Contare i tentativi e poi riportare gli esiti. Registrare come mancato raggiungimento anche il superamento del tempo massimo concordato. Calcolare i tempi dei passaggi riusciti separatamente dai tempi interrotti. Ripetere la prova quando cambia un riferimento, un ruolo o un supporto.

**Esito del perimetro.** Idoneo alla replica, da correggere e riprovare, oppure sospeso. Sospendere se si usano dati o canali reali, si diffonde un avviso senza autorizzazione o manca l’alternativa accessibile al QR. Annotare l’interruzione a livello di gruppo. Le misure descrivono il piccolo gruppo, con nessuna graduatoria individuale.

## Registro dei QR e delle schede

| ID e versione | Posizione o supporto | Recapito e indirizzo in chiaro | Ruolo responsabile | Ultima verifica e data prossima | Esito e azione |
| --- | --- | --- | --- | --- | --- |
| URP-DEMO-02 v2 | Bacheca simulata | Punto informazioni dell’aula della prova | Conduttore di turno | Sessione, nuova prova dopo sette giorni | Verificare copia vecchia e cartello sostituito |
| ___ | ___ | ___ | ___ | ___ | ___ |

Quando si aggiorna una scheda, censire e sostituire le copie affisse. Provare che il testo resti leggibile senza scansione e che una persona sappia verificare l’informazione mediante un recapito ottenuto da una fonte indipendente. Per un uso reale, l’ente concorda frequenza del controllo e modalità per segnalare copie sospette.

## Registro dei canali istituzionali

| Servizio | Canale principale | Alternativa indipendente | Fonte dalla quale è stato verificato il recapito | Ruolo autorizzato e sostituto | Data e motivo del riesame |
| --- | --- | --- | --- | --- | --- |
| URP dimostrativo | Casella di prova | Bacheca e punto informazioni della prova | Scheda del conduttore | Responsabile di turno e sostituto della prova | Ad ogni sessione e quando cambia un ruolo |
| ___ | ___ | ___ | ___ | ___ | ___ |

Il kit è statico. Le scelte in pagina restano nella scheda corrente del browser. Il rapporto si compila a parte con soli dati aggregati.
